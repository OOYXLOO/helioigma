# Solstice Cipher Publishing Gate

Purpose: make the DEV June Solstice Game Jam package publishable with minimal human work while keeping account, payout, tax, and identity gates under the account owner's control.

## Current State

- Local game package is complete and verified.
- Local Git repository can be pushed after a public GitHub repository exists.
- No DEV post, public repo, or public try link exists yet.
- No payout, tax, KYC, bank, API key, password, OTP, or private account data belongs in this package.

## Recommended Public Repository

- Owner: `OOYXLOO`
- Repository name: `solstice-cipher`
- Visibility: public
- Pages source: `main` branch, root folder
- Public try link after Pages is enabled: `https://ooyxloo.github.io/solstice-cipher/`

## One-Minute Human Gate

The account owner should create the public GitHub repository, or approve Codex to do so through an already logged-in browser/CLI session:

1. Open https://github.com/new
2. Repository owner: `OOYXLOO`
3. Repository name: `solstice-cipher`
4. Visibility: public
5. Do not initialize with README, license, or `.gitignore`
6. Create repository

After that, run:

```powershell
powershell -ExecutionPolicy Bypass -File .\publish-after-repo.ps1
powershell -ExecutionPolicy Bypass -File .\publish-after-repo.ps1 -Push
```

Then enable GitHub Pages from `main` / root. If the repository settings page is available, use Settings -> Pages -> Build and deployment -> Deploy from a branch -> `main` -> `/root`.
After the push, the `Verify Solstice Cipher` workflow should pass before the DEV article is published.

## DEV Post Gate

Do not submit on DEV until the public try link works. Use:

- Copy console: `dev-submit-console.html`
- Publish assistant: `publish-assistant.html`
- Push helper: `publish-after-repo.ps1`
- Draft: `dev-post-draft.md`
- Cover image after Pages is live: `https://ooyxloo.github.io/solstice-cipher/cover.png`
- Current GIF demo after Pages is live: `https://ooyxloo.github.io/solstice-cipher/solstice-cipher-demo.gif`
- Optional MP4/WebM assets remain in the package, but the GIF is the canonical current preview.
- Judge pack: `https://ooyxloo.github.io/solstice-cipher/judge.html`
- Smoke test: `https://ooyxloo.github.io/solstice-cipher/smoke.html`
- Proof verifier: `https://ooyxloo.github.io/solstice-cipher/proof-verifier.html`
- Try link: `https://ooyxloo.github.io/solstice-cipher/`
- Source link: `https://github.com/OOYXLOO/solstice-cipher`

The account owner handles DEV login, final post, prize claim, payout, tax, and KYC directly.

## Final Pre-Submit Check

- [ ] `node --check game.js`
- [ ] `powershell -ExecutionPolicy Bypass -File .\public-preflight.ps1`
- [ ] GitHub Actions `Verify Solstice Cipher` passes after the public push.
- [ ] Desktop browser check has no console errors or horizontal overflow.
- [ ] 390px mobile browser check has no console errors or horizontal overflow.
- [ ] Public game shows node-control buttons below the canvas.
- [ ] Public smoke test returns `PASS`.
- [ ] Public proof verifier accepts stable Demo Solve proof `SC-4P-2907-62-Y5VFX1`.
- [ ] `powershell -ExecutionPolicy Bypass -File .\public-preflight.ps1 -Public`
- [ ] Public try link returns HTTP 200.
- [ ] Public try link starts the game.
- [ ] Completed public run reveals a copyable `SC-4P-...` run proof.
- [ ] DEV article uses the official tags: `devchallenge`, `gamechallenge`, `gamedev`.
- [ ] DEV article includes a demo video asset or hosted demo video URL.
- [ ] `dev-submit-console.html` no-go gate is reviewed immediately before publishing.
- [ ] DEV post contains the try link, source link, and clear challenge fit.
- [ ] No account secrets, API keys, payment details, tax data, KYC data, or private contact details are included.
